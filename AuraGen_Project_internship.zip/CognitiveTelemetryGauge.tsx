import React from 'react';
import { MousePointer, Clock, Flame, ShieldAlert, Cpu } from 'lucide-react';
import { TelemetryMetrics } from '../types';

interface CognitiveTelemetryGaugeProps {
  metrics: TelemetryMetrics;
  isSelfHealing: boolean;
}

export const CognitiveTelemetryGauge: React.FC<CognitiveTelemetryGaugeProps> = ({
  metrics,
  isSelfHealing,
}) => {
  const getGaugeColor = (score: number) => {
    if (score >= 75) return 'from-rose-500 to-red-600 shadow-rose-500/50';
    if (score >= 50) return 'from-amber-400 to-orange-500 shadow-amber-500/50';
    return 'from-emerald-400 to-teal-500 shadow-teal-500/50';
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl backdrop-blur-md">
      <div className="flex items-center justify-between mb-4 border-b border-slate-800/80 pb-3">
        <div className="flex items-center space-x-2">
          <Cpu className="w-4 h-4 text-teal-400" />
          <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
            Friction Engine Telemetry
          </h3>
        </div>
        <span className="text-[11px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
          50ms Sampling Rate
        </span>
      </div>

      {/* Main Score Progress Meter */}
      <div className="mb-5">
        <div className="flex justify-between items-baseline mb-1.5">
          <span className="text-xs text-slate-400 font-medium">Cognitive Load Index</span>
          <span className="text-sm font-extrabold font-mono text-white">{metrics.cognitiveLoadScore} / 100</span>
        </div>
                <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
          <div
            className={`h-full rounded-full transition-all duration-300 bg-gradient-to-r ${getGaugeColor(
              metrics.cognitiveLoadScore
            )}`}
            style={{ width: `${metrics.cognitiveLoadScore}%` }}
          />
        </div>
      </div>

      {/* Telemetry Grid Stats */}
      <div className="grid grid-cols-3 gap-3">
        {/* Cursor Speed */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
          <div className="flex items-center text-slate-400 text-xs mb-1 space-x-1">
            <MousePointer className="w-3.5 h-3.5 text-indigo-400" />
            <span>Velocity</span>
          </div>
          <div className="text-base font-bold font-mono text-slate-100">
            {metrics.cursorVelocity} <span className="text-[10px] text-slate-500">px/s</span>
          </div>
        </div>
        {/* Hesitation */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
          <div className="flex items-center text-slate-400 text-xs mb-1 space-x-1">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Hesitation</span>
          </div>
                    <div className="text-base font-bold font-mono text-slate-100">
            {(metrics.hesitationTimeMs / 1000).toFixed(1)} <span className="text-[10px] text-slate-500">s</span>
          </div>
        </div>
        {/* Rage Clicks */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
          <div className="flex items-center text-slate-400 text-xs mb-1 space-x-1">
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span>Rage Clicks</span>
          </div>
          <div className="text-base font-bold font-mono text-slate-100">
            {metrics.rageClickCount}
          </div>
        </div>
      </div>
      {/* Status Notice */}
      <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center space-x-1.5">
          <ShieldAlert className="w-4 h-4 text-teal-400" />
          <span>Auto-Healing Threshold: <strong>75% Load</strong></span>
        </div>
        {isSelfHealing && (
          <span className="text-teal-400 font-medium animate-pulse">
            ● Active Morph Mode
          </span>
        )}
      </div>
    </div>
  );
};
