export interface TelemetryMetrics {
  cursorVelocity: number;       // px/s
  hesitationTimeMs: number;     // ms
  rageClickCount: number;
  clickErrorCount: number;
  cognitiveLoadScore: number;   // 0 - 100
  frictionStatus: 'OPTIMAL' | 'MODERATE' | 'HIGH' | 'CRITICAL';
}
export interface FinancialFormData {
  fullName: string;
  ssnTaxId: string;
  grossIncome: string;
  monthlyDebt: string;
  requestedLoanAmount: string;
  collateralType: string;
  collateralEstimatedValue: string;
  amortizationYears: string;
  creditTier: string;
}
export interface ASTValidationResult {
  passed: boolean;
  nodesScanned: number;
  disallowedTokensFound: string[];
  astTreePreview: string;
  sanitizedComponentSignature: string;
  compilationTimeMs: number;
}
export interface SystemLog {
  id: string;
  timestamp: string;
  type: 'TELEMETRY' | 'AI_AGENT' | 'AST_SAFETY' | 'DYNAMIC_RENDER';
  message: string;
  status: 'info' | 'success' | 'warning' | 'error';
}
