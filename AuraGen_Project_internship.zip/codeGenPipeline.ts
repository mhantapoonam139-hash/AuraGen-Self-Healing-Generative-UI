export interface GeneratedWizardStep {
  id: number;
  title: string;
  subtitle: string;
  fieldKey: string;
  fieldLabel: string;
  inputType: 'text' | 'number' | 'select';
  options?: string[];
  helperTip: string;
}
export function generateAuraGenWizardSteps(): GeneratedWizardStep[] {
  return [
    {
      id: 1,
      title: "Applicant Identity & Verification",
      subtitle: "Let's start with your basic information without complex financial jargon.",
      fieldKey: "fullName",
      fieldLabel: "What is your full legal name?",
      inputType: "text",
      helperTip: "Enter your name exactly as shown on your state photo ID or passport."
    },
    {
      id: 2,
      title: "Tax & Identification",
      subtitle: "Secured encrypted identity lookup for tax compliance.",
      fieldKey: "ssnTaxId",
      fieldLabel: "SSN or Taxpayer Identification Number",
      inputType: "text",
      helperTip: "Format: XXX-XX-XXXX. Your SSN is 256-bit encrypted and never stored in plain text."
    },
        {
      id: 3,
      title: "Income & Financial Capability",
      subtitle: "We will auto-calculate your optimal monthly repayment buffer.",
      fieldKey: "grossIncome",
      fieldLabel: "Annual Gross Household Income ($)",
      inputType: "number",
      helperTip: "Include total annual salaries, bonuses, or recurring business revenues before tax."
    },
    {
      id: 4,
      title: "Existing Liabilities & Obligations",
      subtitle: "Estimating your debt-to-income (DTI) health score.",
      fieldKey: "monthlyDebt",
      fieldLabel: "Total Monthly Debt Payments ($)",
      inputType: "number",
      helperTip: "Sum of current credit card minimums, auto loans, and existing mortgages."
    },
    {
      id: 5,
      title: "Loan Facility Details",
      subtitle: "Tailored commercial structure with transparent rate preview.",
      fieldKey: "requestedLoanAmount",
      fieldLabel: "Target Facility Loan Amount ($)",
      inputType: "number",
      helperTip: "Requested funding amount for enterprise growth or equipment acquisition."
    },
  ];
}
export const SAMPLE_GENERATED_REACT_CODE = `import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, ArrowRight, ShieldCheck } from 'lucide-react';
export default function DynamicSelfHealingWizard({ formData, onUpdate, onComplete }) {
  const [step, setStep] = useState(0);
  // AST Validated & Tailwind Sandboxed Component
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      className="p-8 bg-slate-900/90 border border-indigo-500/40 rounded-3xl shadow-2xl backdrop-blur-xl"
    >
      <div className="flex items-center justify-between mb-6">
        <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest bg-indigo-950/80 px-3 py-1 rounded-full border border-indigo-800">
          AuraGen Auto-Adapted Step {step + 1} / 5
        </span>
        <div className="flex items-center text-emerald-400 text-xs font-semibold">
          <ShieldCheck className="w-4 h-4 mr-1" /> AST Security Verified
        </div>
      </div>
      
      {/* Dynamic Conversational Step Container */}
      <h2 className="text-2xl font-bold text-white mb-2">Step {step + 1}: Financial Detail</h2>
      <p className="text-slate-400 text-sm mb-6">Simplified automatically due to detected UI friction.</p>
      <button onClick={() => setStep((prev) => Math.min(prev + 1, 4))} className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold">
        Continue Next Step
      </button>
    </motion.div>
  );
}`;