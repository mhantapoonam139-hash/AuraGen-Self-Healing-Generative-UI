import React from 'react';
import { HelpCircle, AlertTriangle, Building2, Lock, ArrowRight } from 'lucide-react';
import { FinancialFormData } from '../types';
interface ComplexFinancialFormProps {
  formData: FinancialFormData;
  onChange: (field: keyof FinancialFormData, value: string) => void;
  onRegisterClick: () => void;
  onSimulateFriction: () => void;
}
export const ComplexFinancialForm: React.FC<ComplexFinancialFormProps> = ({
  formData,
  onChange,
  onRegisterClick,
  onSimulateFriction,
}) => {
  return (
    <div 
      className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden"
      onClick={onRegisterClick}
    >
      {/* Intimidating Corporate Top Header */}
      <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-6 mb-6 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-indigo-400" />
            <h2 className="text-xl font-bold text-white tracking-tight">
              Infotact Commercial Credit & Term Loan Assessment
            </h2>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Form 1040-CL • Institutional Underwriting Standard Section 4(b)
          </p>
        </div>
                <div className="flex items-center space-x-2 text-xs text-amber-400 bg-amber-950/40 border border-amber-800/60 px-3 py-1.5 rounded-lg">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          <span>High Friction UI (Dense Input)</span>
        </div>
      </div>
      {/* Intimidating Form Grid */}
      <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Full Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Primary Applicant Entity / Legal Name <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              value={formData.fullName}
              onChange={(e) => onChange('fullName', e.target.value)}
              placeholder="e.g. Johnathan Doe Corp"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
            />
          </div>
          {/* SSN / Tax ID */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center">
                TIN / SSN / EIN Identification <span className="text-rose-400 ml-0.5">*</span>
              </label>
              <div className="group relative">
                <HelpCircle className="w-4 h-4 text-slate-500 hover:text-indigo-400 cursor-pointer" />
                <div className="absolute right-0 bottom-6 hidden group-hover:block w-64 p-2 bg-slate-800 text-[11px] text-slate-300 rounded-lg border border-slate-700 shadow-xl z-20">
                  Must be 9 digits without hyphens unless filing Schedule C under sole proprietor EIN.
                </div>
              </div>
            </div>
            <input
                          type="text"
              value={formData.ssnTaxId}
              onChange={(e) => onChange('ssnTaxId', e.target.value)}
              placeholder="XXX-XX-XXXX"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
          </div>
          {/* Gross Income */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Audited Gross Household Revenue ($ USD) <span className="text-rose-400">*</span>
            </label>
            <input
              type="number"
              value={formData.grossIncome}
              onChange={(e) => onChange('grossIncome', e.target.value)}
              placeholder="150000"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
          </div>
          {/* Monthly Debt Obligations */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Aggregate Monthly Debt Obligations ($) <span className="text-rose-400">*</span>
            </label>
            <input
              type="number"
              value={formData.monthlyDebt}
              onChange={(e) => onChange('monthlyDebt', e.target.value)}
              placeholder="3200"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
          </div>
                    {/* Target Facility Loan Amount */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Requested Commercial Line ($ USD) <span className="text-rose-400">*</span>
            </label>
            <input
              type="number"
              value={formData.requestedLoanAmount}
              onChange={(e) => onChange('requestedLoanAmount', e.target.value)}
              placeholder="500000"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
          </div>
          {/* Amortization Term */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Amortization Term Schedule (Years)
            </label>
            <select
              value={formData.amortizationYears}
              onChange={(e) => onChange('amortizationYears', e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="5">5 Years (Standard Balloon)</option>
              <option value="10">10 Years (Commercial Fixed)</option>
              <option value="15">15 Years (Extended Facility)</option>
              <option value="30">30 Years (Institutional Prime)</option>
            </select>
          </div>
        </div>
                {/* Dense Collateral Section */}
        <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-4">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
            <span>Collateral Guarantee Assessment</span>
            <span className="text-[10px] text-slate-500">LTV Target &lt; 75%</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Asset Class</label>
              <input
                type="text"
                value={formData.collateralType}
                onChange={(e) => onChange('collateralType', e.target.value)}
                placeholder="e.g. Commercial Real Estate / Equipment"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Estimated Asset Value ($)</label>
              <input
                type="number"
                value={formData.collateralEstimatedValue}
                onChange={(e) => onChange('collateralEstimatedValue', e.target.value)}
                placeholder="750000"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
          </div>
        </div>
                {/* Action Buttons & Rage Trigger Banner */}
        <div className="flex flex-wrap items-center justify-between pt-4 border-t border-slate-800 gap-4">
          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <Lock className="w-3.5 h-3.5 text-teal-400" />
            <span>256-Bit SSL Encrypted Submission</span>
          </div>
          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={onSimulateFriction}
              className="px-4 py-2.5 bg-amber-950/80 hover:bg-amber-900 text-amber-300 border border-amber-700/60 rounded-xl text-xs font-semibold transition-all shadow-md flex items-center space-x-2"
            >
              <span>⚡ Trigger Confusion / Rage Click</span>
            </button>
            <button
              type="submit"
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-sm transition-all shadow-lg shadow-indigo-600/30 flex items-center space-x-2"
            >
              <span>Submit Commercial Filing</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
