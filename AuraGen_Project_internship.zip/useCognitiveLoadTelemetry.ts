import { useState, useEffect, useRef, useCallback } from 'react';
import { TelemetryMetrics } from '../types';
export function useCognitiveLoadTelemetry(autoTriggerThreshold: number = 75) {
  const [metrics, setMetrics] = useState<TelemetryMetrics>({
    cursorVelocity: 0,
    hesitationTimeMs: 0,
    rageClickCount: 0,
    clickErrorCount: 0,
    cognitiveLoadScore: 18,
    frictionStatus: 'OPTIMAL',
  });
  const [isSelfHealingTriggered, setIsSelfHealingTriggered] = useState(false);
  const [autoHealEnabled, setAutoHealEnabled] = useState(true);
  // References for telemetry calculation
  const lastPosRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const clickTimestampsRef = useRef<number[]>([]);
  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastActivityTimeRef = useRef<number>(Date.now());
  const hesitationMsRef = useRef<number>(0);
  const erraticMovementsRef = useRef<number>(0);
  // Calculate Cognitive Load Score & Status
  const updateScore = useCallback((rageClicks: number, hesitations: number, clickErrors: number, velocity: number) => {
    // Formula for Cognitive Load Score (0-100)
    let score = Math.min(
      100,
      Math.max(
        12,
        Math.round(
          rageClicks * 28 +
          (hesitations / 200) +
          clickErrors * 15 +
          (velocity > 1200 ? 15 : 0)
        )
      )
    );
        let status: TelemetryMetrics['frictionStatus'] = 'OPTIMAL';
    if (score >= 75) status = 'CRITICAL';
    else if (score >= 55) status = 'HIGH';
    else if (score >= 35) status = 'MODERATE';
    setMetrics({
      cursorVelocity: Math.round(velocity),
      hesitationTimeMs: Math.round(hesitations),
      rageClickCount: rageClicks,
      clickErrorCount: clickErrors,
      cognitiveLoadScore: score,
      frictionStatus: status,
    });
    if (autoHealEnabled && score >= autoTriggerThreshold && !isSelfHealingTriggered) {
      setIsSelfHealingTriggered(true);
    }
  }, [autoHealEnabled, autoTriggerThreshold, isSelfHealingTriggered]);
  // Handle Mouse Movements
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const now = Date.now();
      const last = lastPosRef.current;
      if (last) {
        const dx = e.clientX - last.x;
        const dy = e.clientY - last.y;
        const dt = (now - last.time) / 1000;
        if (dt > 0.01) {
          const distance = Math.sqrt(dx * dx + dy * dy);
          const velocity = distance / dt;
                    // Erratic sudden movements
          if (velocity > 1800) {
            erraticMovementsRef.current += 1;
          }
          const currentHesitation = now - lastActivityTimeRef.current;
          updateScore(clickTimestampsRef.current.length, currentHesitation, 0, velocity);
        }
      }
      lastPosRef.current = { x: e.clientX, y: e.clientY, time: now };
      lastActivityTimeRef.current = now;
      // Reset idle timer
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
      idleTimerRef.current = setTimeout(() => {
        const hesitationDuration = Date.now() - lastActivityTimeRef.current;
        hesitationMsRef.current = hesitationDuration;
        updateScore(clickTimestampsRef.current.length, hesitationDuration, 0, 0);
      }, 1000);
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    };
  }, [updateScore]);
    // Handle Clicks (Rage Click Detection)
  const registerClick = useCallback(() => {
    const now = Date.now();
    const timestamps = [...clickTimestampsRef.current, now].filter(
      (t) => now - t < 1500 // count clicks within 1.5s
    );
    clickTimestampsRef.current = timestamps;
    const rageClicksCount = timestamps.length >= 3 ? timestamps.length - 2 : 0;
    updateScore(rageClicksCount, hesitationMsRef.current, 0, metrics.cursorVelocity);
  }, [metrics.cursorVelocity, updateScore]);
  // Trigger manual simulation of High Friction / Rage Click
  const simulateRageClick = useCallback(() => {
    const now = Date.now();
    clickTimestampsRef.current = [now - 300, now - 200, now - 100, now];
    hesitationMsRef.current = 4200;
    updateScore(4, 4200, 2, 1600);
    setIsSelfHealingTriggered(true);
  }, [updateScore]);
  const resetTelemetry = useCallback(() => {
    clickTimestampsRef.current = [];
    hesitationMsRef.current = 0;
    erraticMovementsRef.current = 0;
    setIsSelfHealingTriggered(false);
    setMetrics({
      cursorVelocity: 0,
      hesitationTimeMs: 0,
      rageClickCount: 0,
      clickErrorCount: 0,
      cognitiveLoadScore: 18,
      frictionStatus: 'OPTIMAL',
    });
  }, []);
   return {
    metrics,
    isSelfHealingTriggered,
    setIsSelfHealingTriggered,
    autoHealEnabled,
    setAutoHealEnabled,
    registerClick,
    simulateRageClick,
    resetTelemetry,
  };
}