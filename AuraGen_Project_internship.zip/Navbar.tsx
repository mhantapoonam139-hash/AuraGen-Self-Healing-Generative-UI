import React from 'react';
import { Cpu, ShieldCheck, Activity, RefreshCw, Zap } from 'lucide-react';
import { TelemetryMetrics } from '../types';
interface NavbarProps {
  metrics: TelemetryMetrics;
  isSelfHealing: boolean;
  onReset: () => void;
  onSimulateRageClick: () => void;
  onOpenASTModal: () => void;
}
export const Navbar: React.FC<NavbarProps> = ({
  metrics,
  isSelfHealing,
  onReset,
  onSimulateRageClick,
  onOpenASTModal,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800 px-6 py-4">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Project Name */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-teal-500 to-cyan-400 p-0.5 shadow-lg shadow-indigo-500/20">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Cpu className="w-5 h-5 text-teal-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-white text-lg tracking-tight">AuraGen</span>
              <span className="text-[10px] font-semibold tracking-wider text-teal-400 bg-teal-950/80 px-2 py-0.5 rounded-full border border-teal-800 uppercase">
                Self-Healing UI
              </span>
            </div>
            <p className="text-xs text-slate-400">Infotact Solutions • Real-Time Cognitive Load Engine</p>
          </div>
        </div>
                {/* Cognitive Load Metric Bar */}
        <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 space-x-6">
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-indigo-400 animate-pulse" />
            <div>
              <div className="text-[11px] text-slate-400 uppercase font-mono">Cognitive Friction</div>
              <div className="flex items-center space-x-2">
                <span className={`text-base font-extrabold font-mono ${
                  metrics.cognitiveLoadScore > 70 ? 'text-rose-400' :
                  metrics.cognitiveLoadScore > 40 ? 'text-amber-400' : 'text-emerald-400'
                }`}>
                  {metrics.cognitiveLoadScore}%
                </span>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                  metrics.frictionStatus === 'CRITICAL' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                  metrics.frictionStatus === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                  'bg-emerald-950 text-emerald-300 border border-emerald-800'
                }`}>
                  {metrics.frictionStatus}
                </span>
              </div>
            </div>
          </div>
          <div className="hidden sm:block h-8 w-px bg-slate-800" />
          <div className="hidden sm:flex items-center space-x-4">
            <div>
              <div className="text-[11px] text-slate-400 uppercase font-mono">Mode</div>
              <div className="text-xs font-semibold text-slate-200">
                {isSelfHealing ? '⚡ Auto-Adapted Wizard' : '📋 Static Complex Form'}
              </div>
            </div>
          </div>
        </div>
                {/* Interactive Action Controls */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onSimulateRageClick}
            className="flex items-center space-x-1.5 px-3 py-2 text-xs font-medium text-amber-300 bg-amber-950/60 hover:bg-amber-900/80 border border-amber-700/50 rounded-lg transition-all shadow-sm"
            title="Simulate user confusion and rage clicks to test AI self-healing"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Simulate Friction</span>
          </button>
          <button
            onClick={onOpenASTModal}
            className="flex items-center space-x-1.5 px-3 py-2 text-xs font-medium text-indigo-300 bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-700/50 rounded-lg transition-all shadow-sm"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden md:inline">Inspect AST Code</span>
          </button>
          <button
            onClick={onReset}
            className="p-2 text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors"
            title="Reset Telemetry & UI State"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
